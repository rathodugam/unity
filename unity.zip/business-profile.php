<?php
    include "include/header.php";
?>

<section class="owner-profie-sec">
        <div class="container-fluid p-0">
                <div class="row two-col-row">
                        <div class="col store-menu-col p-0">
                            <div class="left-store-menu">
                                <h2 class="owner-name">Hello, Shannon L Woods</h2>
                                <ul>
                                    <li><a href="business-profile.php" class="active">My Profile</a></li>
                                    <li><a href="store-product-list.php">My Products</a></li>
                                    <li><a href="updated-donators.php">Updated Donators <span class="notification-icon"><i class="fas fa-bell"></i></span></a></li>
                                    <li><a href="my-payment.php">Payment Detail</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9 store-content-col">
                            <div class="store-content-wrap">
                                <div class="top-heading">
                                     <h2>My Profile</h2>
                                     <div class="site-btn-4 btn-common">
                                        <a href="#">Edit Profile</a>
                                     </div>
                                </div>
                                <div class="profile-hero-section">
                                    <div class="left-profile align-items-center">
                                        <div class="profile-image">
                                            <div class="profile-box-img"><img class="author-avtar" src="images/profile.png"></div>
                                        </div>
                                        <div class="profile-description">
                                            <h3>Shannon L Woods</h3>
                                            <div class="unity-user-main"><span class="unity-user">UNITY@SHANNON45</span></div>
                                        </div>
                                    </div>
                                </div>
                            <div class="business-profile_wrapp mt-4">
                                <div class="row">
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="Shannon">
                                        <label for="FirstName">First Name</label>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="Woods">
                                        <label for="LastName">Last Name</label>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="email" class="form-control" value="shannonwoods@gmail.com">
                                        <label for="Email">Email</label>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="tel" class="form-control" value="123-456-7890">
                                        <label for="Phone">Phone Number</label>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="Xyz">
                                        <label for="StoreName">Store Name</label>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="London">
                                        <label for="StoreLocation">Store Location</label>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="12345">
                                        <label for="PostCode">Post Code</label>
                                      </div>
                                    </div>
                                    <div class="col-md-6">
                                      <div class="form-floating mb-3">
                                        <input type="tel" class="form-control" value="United Kingdom">
                                        <label for="Country">Country</label>
                                      </div>
                                    </div>
                                    <div class="col-md-12 text-center">
                                      <div class="site-btn-4 btn-common">
                                          <a href="#">Update</a>
                                      </div>
                                    </div>
                                  </div>
                              </div>
                            </div>
                            </div>  
                        </div>
                </div>
        </div>
</section>

<?php
    include "include/footer.php";
?>