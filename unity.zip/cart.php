<?php
   include "include/header.php";
   ?>



<section class="shopping_cart d-padding">
    <div class="container">
        <h2 class="text-center mb-5">Shopping Cart</h2>
        <table>
            <thead>
                <tr>
                    <th></th>
                    <th>PRODUCT</th>
                    <th>PRICE</th>
                    <th>QUANTITY</th>
                    <th>SUBTOTAL</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><a href="#"><i class="fas fa-times"></i></a></td>
                    <td>
                        <div class="product_sec">
                            <img src="images/product-2.png" alt="" class="rounded">
                            <h2><a href="product-detail.php">Dumb Blonde Roast Cofee</a></h2>
                        </div>
                    </td>
                    <td>$20.00</td>
                    <td>
                        <div class="quantity">
                            <div class="number">
                                <span class="minus"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                <input type="text" value="1"/>
                                <span class="plus"><i class="fa fa-plus" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </td>
                    <td>$20.00</td>
                </tr>
                <tr>
                    <td><a href="#"><i class="fas fa-times"></i></a></td>
                    <td>
                        <div class="product_sec">
                            <img src="images/product-1.png" alt="" class="rounded">
                            <h2><a href="product-detail.php">Big Tasty with Bacon</a></h2>
                        </div>
                    </td>
                    <td>$20.00</td>
                    <td>
                        <div class="quantity">
                            <div class="number">
                                <span class="minus"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                <input type="text" value="1"/>
                                <span class="plus"><i class="fa fa-plus" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </td>
                    <td>$20.00</td>
                </tr>
                <tr>
                    <td><a href="#"><i class="fas fa-times"></i></a></td>
                    <td>
                        <div class="product_sec">
                            <img src="images/product-4.png" alt="" class="rounded">
                            <h2><a href="product-detail.php">2 Beds at Mattison Center</a></h2>
                        </div>
                    </td>
                    <td>$20.00</td>
                    <td>
                        <div class="quantity">
                            <div class="number">
                                <span class="minus"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                <input type="text" value="1"/>
                                <span class="plus"><i class="fa fa-plus" aria-hidden="true"></i></span>
                            </div>
                        </div>
                    </td>
                    <td>$20.00</td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5">
                        <div class="site-btn-4 btn-common text-end">
                              <a href="product-detail.php">Update Cart</a>
                          </div>
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
</section>

<section class="subtotal_wrapp pb-5">
    <div class="container">
        <div class="row justify-content-end">
            <div class="col-md-4">
                <div class="subtotal_wrapp_inner">
                    <table>
                        <tbody>
                            <tr>
                                <th class="text-start">Subtotal</th>
                                <td class="text-end">$60.00</td>
                            </tr>
                            <tr>
                                <th class="text-start">Shipping</th>
                                <td class="text-end">$10.00</td>
                            </tr>
                            <tr>
                                <th class="text-start">Total</th>
                                <td class="text-end">$70.00</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2">
                                    <div class="site-btn-4 btn-common text-center">
                                      <a href="checkout.php" class="w-100">Proceed to CheckOut</a>
                                  </div>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>



<?php
   include "include/footer.php";
   ?>