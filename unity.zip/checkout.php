<?php
   include "include/header.php";
   ?>



<section class="checkout d-padding">
    <div class="container">
        <h2 class="text-center mb-5">Checkout</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="billing_detail">
                    <h4 class="mb-3">Billing details</h4>
                    <form action="">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" value="Ben">
                                    <label for="FirstName">First Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" value="Daly">
                                    <label for="LastName">Last Name</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="Company Name">
                                    <label for="CompanyName">Company Name</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" value="United Kingdom (UK)">
                                    <label for="Country">Country</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="Street Address">
                                    <label for="StreetAddress">Street address</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="Town / City">
                                    <label for="Town">Town / City</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="Postcode">
                                    <label for="Postcode">Postcode</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" value="0123 456 789">
                                    <label for="PhoneNumber">Phone Number</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" value="bendaly@gmail.com">
                                    <label for="EmailAddress">Email Address</label>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="accordion" id="accordionExample">
                  <div class="accordion-item">
                    <h2 class="accordion-header" id="headingOne">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Ship to a different address?
                      </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                        <form action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="Ben">
                                        <label for="FirstName">First Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="Daly">
                                        <label for="LastName">Last Name</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="Company Name">
                                        <label for="CompanyName">Company Name</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" value="United Kingdom (UK)">
                                        <label for="Country">Country</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="Street Address">
                                        <label for="StreetAddress">Street address</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="Town / City">
                                        <label for="Town">Town / City</label>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" placeholder="Postcode">
                                        <label for="Postcode">Postcode</label>
                                    </div>
                                </div>
                            </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="order_note">
                    <div class="form-floating mb-3 mt-4">
                        <textarea class="form-control" placeholder="Order notes (optional)" rows="5"></textarea>
                        <label for="Ordernotes">Order notes (optional)</label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="subtotal_wrapp pb-5">
    <div class="container">
        <h4 class="mb-3">Your Order</h4>
        <div class="row">
            <div class="col-md-12">
                <div class="subtotal_wrapp_inner">
                    <table>
                        <thead>
                            <tr>
                                <th>PRODUCT</th>
                                <th class="text-end">SUBTOTAL</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Dumb Blonde Roast Cofee</td>
                                <td class="text-end">$20.00</td>
                            </tr>
                            <tr>
                                <td>Big Tasty with Bacon</td>
                                <td class="text-end">$20.00</td>
                            </tr>
                            <tr>
                                <td>2 Beds at Mattison Center</td>
                                <td class="text-end">$20.00</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td class="text-end" width="80%"><b>Subtotal</b></td>
                                <td class="text-end">$60.00</td>
                            </tr>
                            <tr>
                                <td class="text-end" width="80%"><b>Shipping</b></td>
                                <td class="text-end">Free Shipping</td>
                            </tr>
                            <tr>
                                <td class="text-end" width="80%"><b>Total</b></td>
                                <td class="text-end"><b>$60.00</b></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="payment_wrapp pb-5">
    <div class="container">
        <div class="payment_wrapp_inner p-4">
            <label for="payment_method_paypal"> PayPal <img src="images/payment-card.png" alt="PayPal acceptance mark"> </label>
            <div class="payment_box payment_method_paypal">
                <p>Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.</p>
            </div>
            <div class="site-btn-4 btn-common text-end mt-4">
              <a href="#">Proceed to Paypal</a>
          </div>
        </div>
    </div>
</section>



<?php
   include "include/footer.php";
   ?>