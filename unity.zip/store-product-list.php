<?php
    include "include/header.php";
?>

<section class="owner-profie-sec">
        <div class="container-fluid p-0">
                <div class="row two-col-row">
                        <div class="col store-menu-col p-0">
                            <div class="left-store-menu">
                                <h2 class="owner-name">Hello, Shannon L Woods</h2>
                                <ul>
                                    <li><a href="business-profile.php">My Profile</a></li>
                                    <li><a href="store-product-list.php" class="active">My Products</a></li>
                                    <li><a href="updated-donators.php">Updated Donators <span class="notification-icon"><i class="fas fa-bell"></i></span></a></li>
                                    <li><a href="my-payment.php">Payment Detail</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9 store-content-col">
                            <div class="store-content-wrap">
                                <div class="top-heading">
                                     <h2>My Product List</h2>
                                     <div class="site-btn-4 btn-common">
                                        <a href="add-product.php"> Add Product</a>
                                     </div>
                                </div>
                                <ul class="product-list-part">
                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>

                                    <li>
                                        
                                        <p class="qty-box"> Qty <span>10</span></p>
                                        <div class="product-img-content">
                                             <div class="store-img">
                                                <img src="images/product-1.png">
                                            </div>
                                            <div class="product-brief">
                                                <h3>Store Name</h3>    
                                                <h2>Big Tasty with Bacon</h2>
                                                <p>99 Foregate Street</p>
                                            </div> 
                                        </div>
                                       
                                        <div class="bottom-edit-part">
                                            <a href="#"><i class="far fa-edit"></i></a>
                                            <a href="#"><i class="fas fa-trash"></i></a>
                                        </div>
                                    </li>
                                </ul>
                                
                            </div>
                        </div>
                </div>
        </div>
</section>

<?php
    include "include/footer.php";
?>