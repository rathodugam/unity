<?php
   include "include/header.php";
   ?>



<section class="product_detail d-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="product_img">
                    <img src="images/product-2.png" alt="" class="rounded">
                </div>
            </div>
            <div class="col-md-7">
                <div class="product_right_detail ps-5">
                    <h4>Starbucks</h4>
                    <h2 class="mb-3">Dumb Blonde Roast Cofee</h2>
                    <p class="location"><i class="fas fa-map-marker-alt"></i> 66 Glenurquhart Road, EH14 6ND</p>
                    <div class="price mb-3">
                        <h3>$20.00</h3>
                    </div>
                    <p>Suspendisse in justo mauris. Morbi vitae lectus est. Pellentesque commodo nisi id erat pretium, sit amet facilisis orci condimentum. Nam urna diam, pulvinar ut purus ornare, condimentum tincidunt justo. Suspendisse sed risus enim.</p>
                    <!-- <h5 class="mb-3">Remaining <span>24</span></h5> -->
                    <div class="quantity">
                        <label for="quantity" class="d-block mb-2">Select Quantity</label>
                        <div class="number">
                            <span class="minus"><i class="fa fa-minus" aria-hidden="true"></i></span>
                            <input type="text" value="1"/>
                            <span class="plus"><i class="fa fa-plus" aria-hidden="true"></i></span>
                        </div>
                    </div>
                    <div class="site-btn-4 btn-common mt-3">
                        <a href="cart.php">Add to Cart</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="product_description mb-5">
    <div class="container">
        <ul class="nav nav-tabs pb-4" id="myTab" role="tablist">
          <li class="nav-item ps-0" role="presentation">
            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Description</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Review</button>
          </li>
        </ul>
        <div class="tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
              <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.</p>
          </div>
          <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
              <div class="review_wrapp">
                  <div class="form-floating mb-3">
                        <textarea class="form-control" placeholder="Review" rows="7"></textarea>
                        <label for="Review">Write Your Review</label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Email Address</label>
                    </div>
                    <div class="site-btn-4 btn-common">
                          <button type="button">Submit</button>
                      </div>
              </div>
          </div>
        </div>
    </div>
</div>



<section class="cta-home bg-blue d-padding">
    <div class="container">
        <div class="row heading-h2 heading-c2  paragraph-w text-center">
            
            <h4>Give your big hand to feed this world</h4>
            <h2>Join Our Action! Every one can help</h2>
            <p>Quidem rem earum illo ad erat hymenaeos sociosqu montes est massa natoque. Cursus adipisicing exercitationem eaque! Sit nibh cursus lobortis velit elit, ridiculus leo, incidunt laboris purus, sed, ultrices ac blanditiis dis, vulputate purus accumsan temporibus iusto, nihil ab repellendus.</p>

            <div class="cta-btns">
                <div class="site-btn-3 btn-common">
                    <a href="business-profile.php">Shop Owner</a>
                </div>
                <div class="site-btn-1 btn-common">
                    <a href="register.php">Donate Now</a>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="d-padding home-bottom-slider">
    <div class="top-heading-part">
        <div class="container">
            <div class="row heading-h2 text-center justify-content-center">
                <div class="col-md-9">
                    <h2>Some of smiley Faces</h2>
                    <p>Totam eu vivamus! Doloremque est omnis possimus torquent et tellus provident eaque aptent natoque quos, sapiente voluptatibus earum, pretium vulputate aliqua sapiente.</p>    
                </div>
                
            </div>
        </div>
    </div>

    <div class="bottom-slider">
        <div class="swiper-container">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <div class="swiper-slide">
                    <img src="images/home-slider-1.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-2.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-3.png">
                </div>

                <div class="swiper-slide">
                    <img src="images/home-slider-4.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-5.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-6.png">
                </div>
                 <div class="swiper-slide">
                    <img src="images/home-slider-7.png">
                </div>
                
            </div>
            
       
        </div>

    </div>
</section>



<?php
   include "include/footer.php";
   ?>