<?php
   include "include/header.php";
   ?>


<section class="inner_header gestures">
    <div class="container">
        <h2>Our Donators</h2>
        <p class="text-white">It’s no secret that what goes around comes around. Offer a kind gesture to someone in need and let that altruistic energy flow. A cup of coffee, some groceries, or just a safe place to sleep; you have the power to make a positive difference in someone's life.</p>
    </div>
</section>

<section class="donators_wrapp d-padding">
    <div class="container">
        <div class="search_wrapp">
            <input type="search" class="form-control" placeholder="Search Donators">
            <button type="button" class="search_btn"><i class="fas fa-search"></i></button>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="donator_box">
                    <div class="donators_info">
                        <div class="donators_img">
                            <img src="images/profile.png" alt="">
                        </div>
                        <h4>Charlie Hartley</h4>
                        <span class="unity-user">
                            UNITY@BENDALY88
                        </span>
                    </div>
                    <div class="remaining">
                        <h4>08 <span>Remaining</span></h4>
                    </div>
                    <ul class="likes_wrapp">
                        <li><a href="#" class="donate"><img src="images/donate.png" alt="">07</a></li>
                        <li><a href="#" class="likes"><img src="images/like.png" alt="">95</a></li>
                    </ul>
                    <div class="message_wrap">
                        <a href="#"><img src="images/message.png" alt=""></a>
                    </div>
                    <div class="thank_wrapp">
                        <a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="pagination justify-content-center mt-4">
          <nav aria-label="Page navigation example">
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#" aria-label="Previous">
                    <span aria-hidden="true">«</span>
                  </a>
                </li>
                <li class="page-item"><a class="page-link current" href="#">01</a></li>
                <li class="page-item"><a class="page-link" href="#">02</a></li>
                <li class="page-item"><a class="page-link" href="#">03</a></li>
                <li class="page-item"><a class="page-link" href="#">04</a></li>
                <li class="page-item"><a class="page-link" href="#">05</a></li>
                <li class="page-item">
                  <a class="page-link" href="#" aria-label="Next">
                    <span aria-hidden="true">»</span>
                  </a>
                </li>
              </ul>
           </nav>
      </div>
    </div>
</section>

<section class="cta-home bg-blue d-padding">
    <div class="container">
        <div class="row heading-h2 heading-c2  paragraph-w text-center">
            
            <h4>Give your big hand to feed this world</h4>
            <h2>Join Our Action! Every one can help</h2>
            <p>Quidem rem earum illo ad erat hymenaeos sociosqu montes est massa natoque. Cursus adipisicing exercitationem eaque! Sit nibh cursus lobortis velit elit, ridiculus leo, incidunt laboris purus, sed, ultrices ac blanditiis dis, vulputate purus accumsan temporibus iusto, nihil ab repellendus.</p>

            <div class="cta-btns">
                <div class="site-btn-3 btn-common">
                    <a href="business-profile.php">Shop Owner</a>
                </div>
                <div class="site-btn-1 btn-common">
                    <a href="register.php">Donate Now</a>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="d-padding home-bottom-slider">
    <div class="top-heading-part">
        <div class="container">
            <div class="row heading-h2 text-center justify-content-center">
                <div class="col-md-9">
                    <h2>Some of smiley Faces</h2>
                    <p>Totam eu vivamus! Doloremque est omnis possimus torquent et tellus provident eaque aptent natoque quos, sapiente voluptatibus earum, pretium vulputate aliqua sapiente.</p>    
                </div>
                
            </div>
        </div>
    </div>

    <div class="bottom-slider">
        <div class="swiper-container">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <div class="swiper-slide">
                    <img src="images/home-slider-1.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-2.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-3.png">
                </div>

                <div class="swiper-slide">
                    <img src="images/home-slider-4.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-5.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-6.png">
                </div>
                 <div class="swiper-slide">
                    <img src="images/home-slider-7.png">
                </div>
                
            </div>
            
       
        </div>

    </div>
</section>



<?php
   include "include/footer.php";
   ?>