<?php
   include "include/header.php";
   ?>
<section class="owner-profie-sec">
   <div class="container-fluid p-0">
   <div class="row two-col-row">
   <div class="col store-menu-col p-0">
      <div class="left-store-menu">
         <h2 class="owner-name">Hello, Shannon L Woods</h2>
         <ul>
            <li><a href="business-profile.php">My Profile</a></li>
            <li><a href="store-product-list.php">My Products</a></li>
            <li><a href="updated-donators.php">Updated Donators <span class="notification-icon"><i class="fas fa-bell"></i></span></a></li>
            <li><a href="my-payment.php" class="active">Payment Detail</a></li>
         </ul>
      </div>
   </div>
   <div class="col-md-9 store-content-col">
      <div class="store-content-wrap">
         <div class="top-heading">
            <h2>Payment Detail</h2>
             <div class="site-btn-4 btn-common">
                <a href="#"> Add Payment Method</a>
             </div>
         </div>
         <div class="payment_card">
            <div class="row">
                <div class="col-md-6">
                    <div class="payment_method_add">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Card Holder Name">
                            <label for="CardHolderName">Card Holder Name</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="CardNumber" placeholder="Card Number">
                            <label for="CardNumber">Card Number</label>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="MM/YY" placeholder="MM/YY">
                                    <label for="MM/YY">MM/YY</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="CVV" placeholder="CVV">
                                    <label for="CVV">CVV</label>
                                </div>
                            </div>
                        </div>
                        <div class="site-btn-4 btn-common">
                              <a href="#">Add Card</a>
                          </div>
                    </div>
                </div>
            </div>
               <!-- <div class="col-md-4">
                  <div class="card">
                     <div class="d-flex justify-content-between">
                         <img class="chip" src="https://img.icons8.com/ios/452/sim-card-chip.png" height="45" >
                         <img class="logo" src="https://gist.githubusercontent.com/beckettnormington/9b6427d6f220b6f94e324c86d01cee30/raw/ad33f00e6e29e8e6662c4accb07bc3b0b90841a0/mastercard.svg" height="60">
                     </div>
                     <p class="digits">1234 5678 9012 3456</p>
                     <div class="d-flex justify-content-between">
                         <p class="name">John Smith</p>
                         <div style="display:block; float:end;">
                            <p class="valid-text">Valid Thru<br><span class="valid-date"> 4/22</span></p>
                         </div>
                     </div>
                  </div>
               </div> -->
            <!-- <div class="donation_table">
               <table>
                   <thead>
                       <tr>
                           <th class="text-start">Date</th>
                           <th class="text-center">Transactions</th>
                           <th class="text-center">Status</th>
                           <th class="text-end">Amount</th>
                       </tr>
                   </thead>
                   <tbody>
                       <tr>
                           <td class="text-start">JAN <span>10</span></td>
                           <td class="text-center">Starbucks</td>
                           <td class="text-center"><span class="alert alert-success m-0 p-2 text-center">Completed</span></td>
                           <td class="text-end">$20.00</td>
                       </tr>
                       <tr>
                           <td class="text-start">JAN <span>10</span></td>
                           <td class="text-center">Starbucks</td>
                           <td class="text-center"><span class="alert alert-info m-0 p-2 text-center">Processing</span></td>
                           <td class="text-end">$28.00</td>
                       </tr>
                       <tr>
                           <td class="text-start">JAN <span>10</span></td>
                           <td class="text-center">Starbucks</td>
                           <td class="text-center"><span class="alert alert-primary m-0 p-2 text-center">On Hold</span></td>
                           <td class="text-end">$105.00</td>
                       </tr>
                       <tr>
                           <td class="text-start">JAN <span>10</span></td>
                           <td class="text-center">Starbucks</td>
                           <td class="text-center"><span class="alert alert-warning m-0 p-2 text-center">Cancelled</span></td>
                           <td class="text-end">$58.00</td>
                       </tr>
                       <tr>
                           <td class="text-start">JAN <span>10</span></td>
                           <td class="text-center">Starbucks</td>
                           <td class="text-center"><span class="alert alert-danger m-0 p-2 text-center">Failed</span></td>
                           <td class="text-end">$76.00</td>
                       </tr>
                   </tbody>
               </table>
               </div>
               </div>   -->
         </div>
      </div>
   </div>
</section>
<?php
   include "include/footer.php";
   ?>