<?php
   include "include/header.php";
   ?>


<section class="inner_header gestures">
    <div class="container">
        <h2>About Us</h2>
        <p class="text-white">It’s no secret that what goes around comes around. Offer a kind gesture to someone in need and let that altruistic energy flow. A cup of coffee, some groceries, or just a safe place to sleep; you have the power to make a positive difference in someone's life.</p>
    </div>
</section>

<section class="about_wrapp d-padding">
    <div class="container">
        <div class="title_main text-center">
            <h3>Help is our Goal</h3>
            <h2 class="mb-4">What Make Us Different</h2>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="about_wrapp_box text-center">
                    <img src="images/about1.png" alt="">
                    <h4>We Educate</h4>
                    <p>We help local nonprofits access the funding, tools, training, and support they need</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="about_wrapp_box text-center">
                    <img src="images/about2.png" alt="">
                    <h4>We Help</h4>
                    <p>We help local nonprofits access the funding, tools, training, and support they need</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="about_wrapp_box text-center">
                    <img src="images/about3.png" alt="">
                    <h4>We Build</h4>
                    <p>We help local nonprofits access the funding, tools, training, and support they need</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="about_wrapp_box text-center">
                    <img src="images/about4.png" alt="">
                    <h4>We Donate</h4>
                    <p>We help local nonprofits access the funding, tools, training, and support they need</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="about_wrapp_two">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-9">
                <h2 class="text-white mb-4">Each donation is an essential help which improves everyone's life</h2>
                <p class="text-white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam nec lobortis diam. Pellentesque nec enim ipsum. Fusce ex nisi, efficitur vel odio eu, egestas mattis .</p>
            </div>
        </div>
    </div>
</section>

<section class="about_wrapp_three d-padding">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-5">
                <div class="about_wrapp_three_img pe-5">
                    <img src="images/aboutimg2.jpg" alt="">
                    <div class="about_wrapp_three_box">
                        <img src="images/icon-white.png" alt="">
                        <h3>+76 <span>DONATIONS</span></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-7">
                <div class="about_wrapp_three_text ps-5">
                    <div class="title_main text-start">
                        <h3>A help to those who need it</h3>
                        <h2 class="mb-4">Each donation is an essential help which improves everyone's life</h2>
                    </div>
                    <p>Quisque eu euismod arcu. Morbi et dapibus diam, sed interdum velit. Proin tempor nunc vel nisl condimentum, nec tempor risus lacinia.</p>
                    <p>Suspendisse a cursus magna. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas non metus ipsum. Integer elementum enim urna.</p>
                    <p>Curabitur a fringilla eros. Pellentesque eu interdum nulla. Pellentesque porttitor dui nec leo condimentum, et euismod mi mollis.</p>
                    <p>Vulputate orci, et ultrices tellus rutrum mollis. Fusce a eros tellus. Ut vitae risus sit amet nisl blandit rutrum quis ac enim. Etiam congue at.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="cta-home bg-blue d-padding">
    <div class="container">
        <div class="row heading-h2 heading-c2  paragraph-w text-center">
            
            <h4>Give your big hand to feed this world</h4>
            <h2>Join Our Action! Every one can help</h2>
            <p>Quidem rem earum illo ad erat hymenaeos sociosqu montes est massa natoque. Cursus adipisicing exercitationem eaque! Sit nibh cursus lobortis velit elit, ridiculus leo, incidunt laboris purus, sed, ultrices ac blanditiis dis, vulputate purus accumsan temporibus iusto, nihil ab repellendus.</p>

            <div class="cta-btns">
                <div class="site-btn-3 btn-common">
                    <a href="business-profile.php">Shop Owner</a>
                </div>
                <div class="site-btn-1 btn-common">
                    <a href="register.php">Donate Now</a>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="d-padding home-bottom-slider">
    <div class="top-heading-part">
        <div class="container">
            <div class="row heading-h2 text-center justify-content-center">
                <div class="col-md-9">
                    <h2>Some of smiley Faces</h2>
                    <p>Totam eu vivamus! Doloremque est omnis possimus torquent et tellus provident eaque aptent natoque quos, sapiente voluptatibus earum, pretium vulputate aliqua sapiente.</p>    
                </div>
                
            </div>
        </div>
    </div>

    <div class="bottom-slider">
        <div class="swiper-container">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <div class="swiper-slide">
                    <img src="images/home-slider-1.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-2.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-3.png">
                </div>

                <div class="swiper-slide">
                    <img src="images/home-slider-4.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-5.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-6.png">
                </div>
                 <div class="swiper-slide">
                    <img src="images/home-slider-7.png">
                </div>
                
            </div>
            
       
        </div>

    </div>
</section>



<?php
   include "include/footer.php";
   ?>