<?php
   include "include/header.php";
   ?>


<section class="inner_header gestures">
    <div class="container">
        <h2>Register</h2>
        <p class="text-white">It’s no secret that what goes around comes around. Offer a kind gesture to someone in need and let that altruistic energy flow. A cup of coffee, some groceries, or just a safe place to sleep; you have the power to make a positive difference in someone's life.</p>
    </div>
</section>

<section class="register_wrapp d-padding">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-md-6">
            <div class="register_box p-4">
               <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                 <li class="nav-item" role="presentation">
                   <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Business Owners Register</button>
                 </li>
                 <li class="nav-item" role="presentation">
                   <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Donators Register</button>
                 </li>
               </ul>
               <div class="tab-content" id="myTabContent">
                 <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <form action="">
                       <div class="row">
                          <div class="col-md-12">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Username">
                                <label for="username">Username</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="First Name">
                                <label for="FirstName">First Name</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Last Name">
                                <label for="LastName">Last Name</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="email" class="form-control" placeholder="Email Address">
                                <label for="Email">Email Address</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="tel" class="form-control" placeholder="Phone Number">
                                <label for="PhoneNumber">Phone Number</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Store Name">
                                <label for="StoreName">Store Name</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Store Location">
                                <label for="StoreLocation">Store Location</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Postal Code">
                                <label for="PostalCode">Postal Code</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Country">
                                <label for="Country">Country</label>
                             </div>
                          </div>
                       </div>
                       <div class="site-btn-4 btn-common text-center">
                           <a href="#" class="w-100">Register</a>
                       </div>
                       <div class="register_log mt-3">
                            <p class="text-center">Already have an account? <a href="login.php">Login</a></p>
                         </div>
                    </form>
                 </div>
                 <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <form action="">
                       <div class="row">
                          <div class="col-md-12">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Username">
                                <label for="username">Username</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="First Name">
                                <label for="FirstName">First Name</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Last Name">
                                <label for="LastName">Last Name</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="email" class="form-control" placeholder="Email Address">
                                <label for="Email">Email Address</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="tel" class="form-control" placeholder="Phone Number">
                                <label for="PhoneNumber">Phone Number</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Store Name">
                                <label for="StoreName">Store Name</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Store Location">
                                <label for="StoreLocation">Store Location</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Postal Code">
                                <label for="PostalCode">Postal Code</label>
                             </div>
                          </div>
                          <div class="col-md-6">
                             <div class="form-floating mb-3">
                                <input type="text" class="form-control" placeholder="Country">
                                <label for="Country">Country</label>
                             </div>
                          </div>
                          <div class="col-md-12">
                             <div class="mb-3">
                                <select name="" id="" class="form-select">
                                   <option value="1">Role One</option>
                                   <option value="2">Role two</option>
                                   <option value="3">Role Three</option>
                                   <option value="4">Role Four</option>
                                </select>
                             </div>
                          </div>
                       </div>
                       <div class="site-btn-4 btn-common text-center">
                           <a href="#">Register</a>
                       </div>
                       <div class="register_log mt-3">
                            <p class="text-center">Already have an account? <a href="login.php">Login</a></p>
                         </div>
                    </form>
                 </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>




<?php
   include "include/footer.php";
   ?>