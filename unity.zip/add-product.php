<?php
    include "include/header.php";
?>

<section class="owner-profie-sec">
    <div class="container-fluid p-0">
        <div class="row two-col-row">
            <div class="col store-menu-col p-0">
                <div class="left-store-menu">
                    <h2 class="owner-name">Hello, Shannon L Woods</h2>
                    <ul>
                        <li><a href="business-profile.php">My Profile</a></li>
                        <li><a href="store-product-list.php" class="active">My Products</a></li>
                        <li><a href="updated-donators.php">Updated Donators <span class="notification-icon"><i class="fas fa-bell"></i></span></a></li>
                        <li><a href="my-payment.php">Payment Detail</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-9 store-content-col">
                <div class="store-content-wrap">
                    <div class="top-heading">
                         <h2>Add Product</h2>
                         <div class="site-btn-4 btn-common">
                            <a href="#"> Add New</a>
                         </div>
                    </div>
                    <div class="add_product_wrapp">
                        <div class="mb-3">
                            <select class="form-select" name="" id="">
                                <option value="1">Select Category</option>
                                <option value="2">Coffee</option>
                                <option value="3">Meals</option>
                                <option value="4">Beds</option>
                            </select>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" placeholder="Product Name">
                            <label for="productName">Product Name</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" placeholder="Store Name">
                            <label for="StoreName">Store Name</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" placeholder="Location">
                            <label for="Location">Location</label>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" placeholder="Regular Price">
                                    <label for="Price">Regular Price ($)</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    <input type="number" class="form-control" placeholder="Quantity">
                                    <label for="Quantity">Quantity</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" placeholder="Description" rows="10"></textarea>
                            <label for="Description">Product Description</label>
                        </div>
                        <div class="mb-3 upload_photo">
                          <label for="formFile" class="form-label">Upload Product Image</label>
                          <input class="form-control" type="file" id="formFile">
                        </div>
                        <div class="site-btn-4 btn-common">
                            <a href="#">Publish</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
    include "include/footer.php";
?>