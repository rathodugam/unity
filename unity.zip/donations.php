<?php
   include "include/header.php";
   ?>


<section class="inner_header gestures">
    <div class="container">
        <h2>Donations</h2>
        <p class="text-white">It’s no secret that what goes around comes around. Offer a kind gesture to someone in need and let that altruistic energy flow. A cup of coffee, some groceries, or just a safe place to sleep; you have the power to make a positive difference in someone's life.</p>
    </div>
</section>


<section class="donations_Wrapp d-padding">
    <div class="container">
        <div class="donation_wrapp_inner p-5 mb-4">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <div class="donation_img">
                        <img src="images/donation1.jpg" alt="">
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="donation_text ps-3">
                        <h4><span>FOOD</span></h4>
                        <h2 class="mb-3"><a href="#">Little Help Can Make a Big Difference</a></h2>
                        <p>Diam volutpat commodo sed egestas egestas fringilla phasellus faucibus scelerisque. Et ligula ullamcorper malesuada proin libero nunc. Quis vel eros donec ac odio tempor. Cursus in hac habitasse platea. Phasellus egestas tellus rutrum tellus pellentesque eu. Non diam</p>
                        <div class="site-btn-4 btn-common">
                            <a href="donations-detail.php">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="donation_wrapp_inner p-5 mb-4">
            <div class="row align-items-center">
                <div class="col-md-5">
                    <div class="donation_text pe-3">
                        <h4><span>COFFEE</span></h4>
                        <h2 class="mb-3"><a href="#">Little Help Can Make a Big Difference</a></h2>
                        <p>Diam volutpat commodo sed egestas egestas fringilla phasellus faucibus scelerisque. Et ligula ullamcorper malesuada proin libero nunc. Quis vel eros donec ac odio tempor. Cursus in hac habitasse platea. Phasellus egestas tellus rutrum tellus pellentesque eu. Non diam</p>
                        <div class="site-btn-4 btn-common">
                            <a href="donations-detail.php">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="donation_img">
                        <img src="images/product-2.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="donation_wrapp_inner p-5 mb-4">
            <div class="row align-items-center">
                <div class="col-md-7">
                    <div class="donation_img">
                        <img src="images/product-4.png" alt="">
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="donation_text ps-3">
                        <h4><span>BEDS</span></h4>
                        <h2 class="mb-3"><a href="#">Little Help Can Make a Big Difference</a></h2>
                        <p>Diam volutpat commodo sed egestas egestas fringilla phasellus faucibus scelerisque. Et ligula ullamcorper malesuada proin libero nunc. Quis vel eros donec ac odio tempor. Cursus in hac habitasse platea. Phasellus egestas tellus rutrum tellus pellentesque eu. Non diam</p>
                        <div class="site-btn-4 btn-common">
                            <a href="donations-detail.php">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php
   include "include/footer.php";
   ?>