<?php
   include "include/header.php";
   ?>


<section class="login">
    <div class="container">
        <div class="row justify-content-center d-padding">
            <div class="col-md-6">
                <div class="login_wrapp p-4">
                    <h2 class="text-center mb-3">Login</h2>
                    <form action="">
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                            <label for="floatingInput">Email Address</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                            <label for="floatingPassword">Password</label>
                        </div>
                        <div class="forgot_password text-end">
                            <a href="#" class="d-inline-block">Forgot Password?</a>
                        </div>
                        <div class="site-btn-4 btn-common text-center">
                          <button type="button" class="w-100">Login</button>
                      </div>
                      <div class="register_log mt-3">
                         <p class="text-center">Don't have an account? <a href="register.php">Register</a></p>
                      </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>





<?php
   include "include/footer.php";
   ?>