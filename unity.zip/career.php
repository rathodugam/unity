<?php
   include "include/header.php";
   ?>


<section class="inner_header gestures">
    <div class="container">
        <h2>Become a Part of Our Big Family</h2>
        <p class="text-white">Join this team of remarkable people and make real change happen. Organizations and volunteers working together for peace and development. This is a movement of active citizens helping people and communities learn to live together.</p>
    </div>
</section>


<section class="career d-padding">
    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>Position</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Apply</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Refugee Education Research Specialist</td>
                    <td>New York</td>
                    <td>Full Time</td>
                    <td>
                        <div class="site-btn-2 btn-common">
                            <a href="add-product.php" class="w-100 text-center">Apply Now</a>
                         </div>
                    </td>
                </tr>
                <tr>
                    <td>Marketing Volunteer</td>
                    <td>Cleveland</td>
                    <td>Full Time</td>
                    <td>
                        <div class="site-btn-2 btn-common">
                            <a href="add-product.php" class="w-100 text-center">Apply Now</a>
                         </div>
                    </td>
                </tr>
                <tr>
                    <td>Teacher Educator</td>
                    <td>London</td>
                    <td>Remote</td>
                    <td>
                        <div class="site-btn-2 btn-common">
                            <a href="add-product.php" class="w-100 text-center">Apply Now</a>
                         </div>
                    </td>
                </tr>
                <tr>
                    <td>Education Management Advisor</td>
                    <td>Lviv</td>
                    <td>Remote</td>
                    <td>
                        <div class="site-btn-2 btn-common">
                            <a href="add-product.php" class="w-100 text-center">Apply Now</a>
                         </div>
                    </td>
                </tr>
                <tr>
                    <td>Social Cohesion and Tolerance Adviser</td>
                    <td>New York</td>
                    <td>Full Time</td>
                    <td>
                        <div class="site-btn-2 btn-common">
                            <a href="add-product.php" class="w-100 text-center">Apply Now</a>
                         </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</section>


<section class="cta-home bg-blue d-padding">
    <div class="container">
        <div class="row heading-h2 heading-c2  paragraph-w text-center">
            
            <h4>Give your big hand to feed this world</h4>
            <h2>Join Our Action! Every one can help</h2>
            <p>Quidem rem earum illo ad erat hymenaeos sociosqu montes est massa natoque. Cursus adipisicing exercitationem eaque! Sit nibh cursus lobortis velit elit, ridiculus leo, incidunt laboris purus, sed, ultrices ac blanditiis dis, vulputate purus accumsan temporibus iusto, nihil ab repellendus.</p>

            <div class="cta-btns">
                <div class="site-btn-3 btn-common">
                    <a href="business-profile.php">Shop Owner</a>
                </div>
                <div class="site-btn-1 btn-common">
                    <a href="register.php">Donate Now</a>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="d-padding home-bottom-slider">
    <div class="top-heading-part">
        <div class="container">
            <div class="row heading-h2 text-center justify-content-center">
                <div class="col-md-9">
                    <h2>Some of smiley Faces</h2>
                    <p>Totam eu vivamus! Doloremque est omnis possimus torquent et tellus provident eaque aptent natoque quos, sapiente voluptatibus earum, pretium vulputate aliqua sapiente.</p>    
                </div>
                
            </div>
        </div>
    </div>

    <div class="bottom-slider">
        <div class="swiper-container">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <div class="swiper-slide">
                    <img src="images/home-slider-1.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-2.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-3.png">
                </div>

                <div class="swiper-slide">
                    <img src="images/home-slider-4.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-5.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-6.png">
                </div>
                 <div class="swiper-slide">
                    <img src="images/home-slider-7.png">
                </div>
                
            </div>
            
       
        </div>

    </div>
</section>



<?php
   include "include/footer.php";
   ?>