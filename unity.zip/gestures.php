<?php
   include "include/header.php";
   ?>


<section class="inner_header gestures">
    <div class="container">
        <h2>Gestures</h2>
        <p class="text-white">It’s no secret that what goes around comes around. Offer a kind gesture to someone in need and let that altruistic energy flow. A cup of coffee, some groceries, or just a safe place to sleep; you have the power to make a positive difference in someone's life.</p>
    </div>
</section>

<section class="gestures_wrapp d-padding ">
    <div class="container">
        <div class="row heading-h2 text-center justify-content-center mb-5">
            <div class="col-md-9">
                <h2>Available Meals/Room/Drinks</h2>
                <p>Suspendisse in justo mauris. Morbi vitae lectus est. Pellentesque commodo nisi id erat pretium, sit amet facilisis orci condimentum. Nam urna diam, pulvinar ut purus ornare, condimentum tincidunt justo. Suspendisse sed risus enim.</p>    
            </div>
        </div>
        <ul class="nav nav-tabs mb-5" id="myTab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="Coffee-tab" data-bs-toggle="tab" data-bs-target="#Coffee" type="button" role="tab" aria-controls="Coffee" aria-selected="true">Coffee</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="Meals-tab" data-bs-toggle="tab" data-bs-target="#Meals" type="button" role="tab" aria-controls="Meals" aria-selected="false">Meals</button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="Bed-tab" data-bs-toggle="tab" data-bs-target="#Bed" type="button" role="tab" aria-controls="Bed" aria-selected="false">Bed</button>
          </li>
        </ul>
        <div class="tab-content" id="myTabContent">
          <div class="tab-pane fade show active" id="Coffee" role="tabpanel" aria-labelledby="Coffee-tab">
              <div class="row">
                  <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Dumb Blonde Roast Cofee</h2>
                               <p class="location">66 Glenurquhart Road, EH14 6ND</p>
                            </div>    
                                <img src="images/product-2.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">12</span></p>
                            </div>
                        </a>
                    </div>
                </div>
              </div>
          </div>
          <div class="tab-pane fade" id="Meals" role="tabpanel" aria-labelledby="Meals-tab">
              <div class="row">
                  <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-box">
                        
                        <a href="product-detail.php">
                            
                            <div class="product-meta-top">
                               <h2>Big Tasty with Bacon</h2>
                               <p class="location">99 Foregate Street</p>
                            </div>    
                                <img src="images/product-1.png">
                            <div class="product-meta-bottom">
                                <p>Remaining <span class="remaining-no">04</span></p>
                            </div>
                        </a>

                    </div>
                </div>
              </div>
          </div>
          <div class="tab-pane fade" id="Bed" role="tabpanel" aria-labelledby="Bed-tab">
              <div class="row">
                  <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
            <div class="col-md-3">
                <div class="product-box">
                    <a href="product-detail.php">
                        
                        <div class="product-meta-top">
                           <h2>2 Beds at Mattison Center</h2>
                           <p class="location">76 Farburn Terrace</p>
                        </div>    
                            <img src="images/product-4.png">
                        <div class="product-meta-bottom">
                            <p>Remaining <span class="remaining-no">18</span></p>
                        </div>
                    </a>

                </div>
            </div>
              </div>
          </div>
        </div>
    </div>
</section>

<section class="cta-home bg-blue d-padding">
    <div class="container">
        <div class="row heading-h2 heading-c2  paragraph-w text-center">
            
            <h4>Give your big hand to feed this world</h4>
            <h2>Join Our Action! Every one can help</h2>
            <p>Quidem rem earum illo ad erat hymenaeos sociosqu montes est massa natoque. Cursus adipisicing exercitationem eaque! Sit nibh cursus lobortis velit elit, ridiculus leo, incidunt laboris purus, sed, ultrices ac blanditiis dis, vulputate purus accumsan temporibus iusto, nihil ab repellendus.</p>

            <div class="cta-btns">
                <div class="site-btn-3 btn-common">
                    <a href="business-profile.php">Shop Owner</a>
                </div>
                <div class="site-btn-1 btn-common">
                    <a href="register.php">Donate Now</a>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="d-padding home-bottom-slider">
    <div class="top-heading-part">
        <div class="container">
            <div class="row heading-h2 text-center justify-content-center">
                <div class="col-md-9">
                    <h2>Some of smiley Faces</h2>
                    <p>Totam eu vivamus! Doloremque est omnis possimus torquent et tellus provident eaque aptent natoque quos, sapiente voluptatibus earum, pretium vulputate aliqua sapiente.</p>    
                </div>
                
            </div>
        </div>
    </div>

    <div class="bottom-slider">
        <div class="swiper-container">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
                <!-- Slides -->
                <div class="swiper-slide">
                    <img src="images/home-slider-1.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-2.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-3.png">
                </div>

                <div class="swiper-slide">
                    <img src="images/home-slider-4.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-5.png">
                </div>
                <div class="swiper-slide">
                    <img src="images/home-slider-6.png">
                </div>
                 <div class="swiper-slide">
                    <img src="images/home-slider-7.png">
                </div>
                
            </div>
            
       
        </div>

    </div>
</section>



<?php
   include "include/footer.php";
   ?>