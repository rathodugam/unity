<?php
    include "include/header.php";
?>

<section class="owner-profie-sec">
        <div class="container-fluid p-0">
                <div class="row two-col-row">
                        <div class="col store-menu-col p-0">
                            <div class="left-store-menu">
                                <h2 class="owner-name">Hello, Shannon L Woods</h2>
                                <ul>
                                    <li><a href="business-profile.php">My Profile</a></li>
                                    <li><a href="store-product-list.php">My Products</a></li>
                                    <li><a href="updated-donators.php" class="active">Updated Donators <span class="notification-icon"><i class="fas fa-bell"></i></span></a></li>
                                    <li><a href="my-payment.php">Payment Detail</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9 store-content-col">
                            <div class="store-content-wrap">
                                <div class="top-heading">
                                     <h2>Updated Donators</h2>
                                </div>
                            <div class="donation_table">
                                  <table>
                                      <thead>
                                          <tr>
                                              <th>date</th>
                                              <th>Donators Name</th>
                                              <th>Price</th>
                                              <th>QTY</th>
                                              <th>Total</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                          <tr>
                                              <td>JAN <span>10</span></td>
                                              <td>Ben Daly</td>
                                              <td>$10</td>
                                              <td>07</td>
                                              <td>$70.00</td>
                                          </tr>
                                          <tr>
                                              <td>FAB <span>10</span></td>
                                              <td>Ben Daly</td>
                                              <td>$10</td>
                                              <td>07</td>
                                              <td>$70.00</td>
                                          </tr>
                                          <tr>
                                              <td>JAN <span>10</span></td>
                                              <td>Ben Daly</td>
                                              <td>$10</td>
                                              <td>07</td>
                                              <td>$70.00</td>
                                          </tr>
                                          <tr>
                                              <td>JAN <span>10</span></td>
                                              <td>Ben Daly</td>
                                              <td>$10</td>
                                              <td>07</td>
                                              <td>$70.00</td>
                                          </tr>
                                      </tbody>
                                  </table>
                              </div>
                            </div>  
                        </div>
                </div>
        </div>
</section>

<?php
    include "include/footer.php";
?>