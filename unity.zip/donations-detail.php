<?php
   include "include/header.php";
   ?>


<section class="inner_header gestures">
    <div class="container">
        <h4><span>FOOD</span></h4>
        <h2>Little Help Can Make a Big Difference</h2>
    </div>
</section>


<section class="donation_detail d-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="donation_detail_img">
                    <img src="images/donation1.jpg" alt="">
                </div>
                <h2 class="mt-3 mb-3">Don’t turn your back to those in need.</h2>
                <p>Lorem Ipsum roin gravida nibh vel velhit auctor alienean sollicitudiorems bibendum auctor, nisi elit consequa, nec sagittis sem nibh id eliis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctorrnare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
                <p>Mauris in erat justo. Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc. Etiam pharetra, erat sed fermentum feugiat, velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
                <h3 class="mb-3">Think about future generations and save earth.</h3>
                <p>Lorem Ipsum roin gravida nibh vel velhit auctor alienean sollicitudiorems bibendum auctor, nisi elit consequa, nec sagittis sem nibh id eliis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctorrnare odio. Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
                <p>Mauris in erat justo. Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc. Etiam pharetra, erat sed fermentum feugiat, velit mauris egestas quam, ut aliquam massa nisl quis neque. Suspendisse in orci enim.</p>
                <hr>
                <div class="review_wrapp">
                    <h3 class="mb-3">Leave a Reply</h3>
                    <form action="">
                        <div class="form-floating mb-3">
                            <textarea class="form-control" placeholder="Review" rows="7"></textarea>
                            <label for="Review">Write Your Review</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                            <label for="floatingInput">Email Address</label>
                        </div>
                        <div class="site-btn-4 btn-common">
                              <button type="button">Post Comment</button>
                        </div>
                    </form>
              </div>
            </div>
        </div>
    </div>
</section>



<?php
   include "include/footer.php";
   ?>