
    <?php
        include "include/header.php";
    ?>


<section class="profile-hero-section d-padding">
    <div class="container">

        <div class="row">

            <div class="col-md-7">
                <div class="left-profile">
                    <div class="profile-image">
                        <div class="profile-box-img"><img class="author-avtar" src="images/profile.png"/></div>
                        <div class="profile-box-content"><a href="#" class="say-thanks">Say thanks!<i class="far fa-smile"></i></a></div>
                    </div>
                    <div class="profile-description">
                        <h3>Ben Daly</h3>
                        <div class="unity-user-main"><span class="unity-user">UNITY@BENDALY88</span></div>
                        <div class="profile-facilities">
                            <div class="facility-box">
                                <div class="facility-box-img"><img src="images/feather-coffee.png"></div>
                                <span class="facility-counter">04</span>
                            </div>
                             <div class="facility-box">
                                <div class="facility-box-img"><img src="images/map-food.png"></div>
                                <span class="facility-counter">04</span>
                            </div>
                             <div class="facility-box">
                                <div class="facility-box-img"><img src="images/awesome-bed.png"></div>
                                <span class="facility-counter">04</span>
                            </div>
                             <div class="facility-box">
                                <div class="facility-box-img"><img src="images/awesome-heart.png"></div>
                                <span class="facility-counter">125</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-5">
                <div class="right-profile">
                    <div class="sharing-quote">
                        <h2>Sharing is caring</h2>
                    </div>
                    <div class="charity-des">
                        <div class="smile-face">
                            <img src="images/smile-face.png">
                        </div>
                        <div class="smile-content">
                            <h2>Favourite Charity <span>St Francis Hospital</span></h2>
                        </div>
                    </div>
                </div>
            </div>
            
            
        </div>
       
    </div>
</section>

<section class="profile_tab_wrapp">
    <div class="tab_head">
        <div class="container">
            <div class="row">
                <div class="col-md-10">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                      <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#profle" type="button" role="tab" aria-controls="profle" aria-selected="true">My Profile</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#donation" type="button" role="tab" aria-controls="donation" aria-selected="false">My Donation</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#comments" type="button" role="tab" aria-controls="comments" aria-selected="false">My Comments</button>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#messages" type="button" role="tab" aria-controls="messages" aria-selected="false">Messages</button>
                      </li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <div class="logout_button">
                        <a href="#">Logout</a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    
    <div class="tab_body">
        <div class="container">
            <div class="tab-content" id="myTabContent">
              <div class="tab-pane fade show active" id="profle" role="tabpanel" aria-labelledby="profle-tab">
                <div class="row justify-content-center">
                  <div class="col-md-8">
                    <div class="edit_profile">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="text" class="form-control" value="Ben">
                            <label for="FirstName">First Name</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="text" class="form-control" value="Daly">
                            <label for="LastName">Last Name</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="email" class="form-control" value="bendaly@gmail.com">
                            <label for="Email">Email</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="tel" class="form-control" value="123-456-7890">
                            <label for="Phone">Phone Number</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="text" class="form-control" value="Xyz">
                            <label for="StoreName">Store Name</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="text" class="form-control" value="London">
                            <label for="StoreLocation">Store Location</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="text" class="form-control" value="12345">
                            <label for="PostCode">Post Code</label>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-floating mb-3">
                            <input type="tel" class="form-control" value="United Kingdom">
                            <label for="Country">Country</label>
                          </div>
                        </div>
                        <div class="col-md-12 text-center">
                          <div class="site-btn-4 btn-common">
                              <a href="#">Update</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="donation" role="tabpanel" aria-labelledby="donation-tab">
                  <div class="donation_table">
                      <table>
                          <thead>
                              <tr>
                                  <th>date</th>
                                  <th>Product Name</th>
                                  <th>Price</th>
                                  <th>QTY</th>
                                  <th>Owener</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr>
                                  <td>JAN <span>10</span></td>
                                  <td>Starbucks Coffe</td>
                                  <td>$10</td>
                                  <td>07</td>
                                  <td>Starbucks <span>Location : London</span></td>
                              </tr>
                              <tr>
                                  <td>FAB <span>10</span></td>
                                  <td>Large Meals</td>
                                  <td>$10</td>
                                  <td>01</td>
                                  <td>Starbucks <span>Location : London</span></td>
                              </tr>
                              <tr>
                                  <td>JAN <span>10</span></td>
                                  <td>Starbucks Coffe</td>
                                  <td>$10</td>
                                  <td>03</td>
                                  <td>Starbucks <span>Location : London</span></td>
                              </tr>
                              <tr>
                                  <td>JAN <span>10</span></td>
                                  <td>Large Meals</td>
                                  <td>$10</td>
                                  <td>04</td>
                                  <td>Starbucks <span>Location : London</span></td>
                              </tr>
                          </tbody>
                      </table>
                  </div>
              </div>
              <div class="tab-pane fade" id="comments" role="tabpanel" aria-labelledby="comments-tab">
                  <div class="row justify-content-center">
                      <div class="col-md-8">
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="comment_date">
                                          <h4>SEP <span>01/2021</span></h4>
                                      </div>
                                  </div>
                                  <div class="col-md-8">
                                      <div class="comment_inner">
                                          <h2>Guest Name</h2>
                                          <p>Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                      </div>
                                  </div>
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="">
                                      </div>
                                  </div>
                              </div>                
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="comment_date">
                                          <h4>JUNE <span>18/2021</span></h4>
                                      </div>
                                  </div>
                                  <div class="col-md-8">
                                      <div class="comment_inner">
                                          <h2>Harry Goodwin</h2>
                                          <p>Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                      </div>
                                  </div>
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="">
                                      </div>
                                  </div>
                              </div>                
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="comment_date">
                                          <h4>JULY <span>04/2021</span></h4>
                                      </div>
                                  </div>
                                  <div class="col-md-8">
                                      <div class="comment_inner">
                                          <h2>Keira Nicholson</h2>
                                          <p>Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                      </div>
                                  </div>
                              </div>                
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="comment_date">
                                          <h4>AUG <span>26/2021</span></h4>
                                      </div>
                                  </div>
                                  <div class="col-md-8">
                                      <div class="comment_inner">
                                          <h2>Harry Goodwin</h2>
                                          <p>Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                      </div>
                                  </div>
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="">
                                      </div>
                                  </div>
                              </div>                
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="comment_date">
                                          <h4>SEP <span>01/2021</span></h4>
                                      </div>
                                  </div>
                                  <div class="col-md-8">
                                      <div class="comment_inner">
                                          <h2>Keira Nicholson</h2>
                                          <p>Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                      </div>
                                  </div>
                              </div>                
                          </div>
                          <div class="pagination justify-content-center mt-5">
                              <nav aria-label="Page navigation example">
                                  <ul class="pagination">
                                    <li class="page-item">
                                      <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                      </a>
                                    </li>
                                    <li class="page-item"><a class="page-link current" href="#">01</a></li>
                                    <li class="page-item"><a class="page-link" href="#">02</a></li>
                                    <li class="page-item"><a class="page-link" href="#">03</a></li>
                                    <li class="page-item"><a class="page-link" href="#">04</a></li>
                                    <li class="page-item"><a class="page-link" href="#">05</a></li>
                                    <li class="page-item">
                                      <a class="page-link" href="#" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                      </a>
                                    </li>
                                  </ul>
                               </nav>
                          </div>    
                      </div>
                  </div>
              </div>
              <div class="tab-pane fade" id="messages" role="tabpanel" aria-labelledby="messages-tab">
                <div class="row justify-content-center">
                      <div class="col-md-8">
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="" class="rounded-circle">
                                      </div>
                                  </div>
                                  <div class="col-md-10">
                                      <div class="comment_inner">
                                          <h2>Guest Name</h2>
                                          <p class="m-0">Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                          <h5>June 18 2021</h5>
                                      </div>
                                  </div>
                              </div>                
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="" class="rounded-circle">
                                      </div>
                                  </div>
                                  <div class="col-md-10">
                                      <div class="comment_inner">
                                          <h2>Harry Goodwin</h2>
                                          <p class="m-0">Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                          <h5>June 18 2021</h5>
                                      </div>
                                  </div>
                              </div>              
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="" class="rounded-circle">
                                      </div>
                                  </div>
                                  <div class="col-md-10">
                                      <div class="comment_inner">
                                          <h2>Keira Nicholson</h2>
                                          <p class="m-0">Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                          <h5>June 18 2021</h5>
                                      </div>
                                  </div>
                              </div>                  
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="" class="rounded-circle">
                                      </div>
                                  </div>
                                  <div class="col-md-10">
                                      <div class="comment_inner">
                                          <h2>Harry Goodwin</h2>
                                          <p class="m-0">Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                          <h5>June 18 2021</h5>
                                      </div>
                                  </div>
                              </div>                  
                          </div>
                          <div class="comments_wrapp p-2 mb-3">
                              <div class="row align-items-center">
                                  <div class="col-md-2">
                                      <div class="user_img">
                                          <img src="images/profile.png" alt="" class="rounded-circle">
                                      </div>
                                  </div>
                                  <div class="col-md-10">
                                      <div class="comment_inner">
                                          <h2>Keira Nicholson</h2>
                                          <p class="m-0">Thanks for the Hot Meal!! Lovely Meal Thank you!!</p>
                                          <h5>June 18 2021</h5>
                                      </div>
                                  </div>
                              </div>                  
                          </div>
                          <div class="pagination justify-content-center mt-5">
                              <nav aria-label="Page navigation example">
                                  <ul class="pagination">
                                    <li class="page-item">
                                      <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                      </a>
                                    </li>
                                    <li class="page-item"><a class="page-link current" href="#">01</a></li>
                                    <li class="page-item"><a class="page-link" href="#">02</a></li>
                                    <li class="page-item"><a class="page-link" href="#">03</a></li>
                                    <li class="page-item"><a class="page-link" href="#">04</a></li>
                                    <li class="page-item"><a class="page-link" href="#">05</a></li>
                                    <li class="page-item">
                                      <a class="page-link" href="#" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                      </a>
                                    </li>
                                  </ul>
                               </nav>
                          </div>    
                      </div>
                  </div>
              </div>
            </div>
        </div>
    </div>
</section>





<?php
    include "include/footer.php";
?>


